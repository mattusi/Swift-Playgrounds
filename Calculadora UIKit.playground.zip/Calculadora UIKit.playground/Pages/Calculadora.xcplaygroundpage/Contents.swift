/* 
 Calculadora desenvolvida por Matheus Tusi, Gustavo Garcia, Eric Zambom.
 Para o Nano-Challange #01 - Apple Developer Academy Senac-SP - Swift Playgrounds Program
 */
import UIKit
import PlaygroundSupport
class ViewController: UIViewController {
    //MARK. define as variveis globais.
    //variavel com o texto do visor
    public var labelText = "0"
    //variavel da instancia do visor
    var label: UILabel!
    //array com o conteudo dos botoes
    var ButtonNames = ["⤵️", "➕", "➖", "➗","7️⃣","8️⃣","9️⃣","✖️","4️⃣","5️⃣","6️⃣"," %","1️⃣","2️⃣","3️⃣"," = ","0️⃣      ", "  ,  ", "Hex"]
    //array com as instancias dos botoes
    var someButtons = [UIButton]()
    //flag para a operacao
    var Operacao: String = "0"
    //variavel com o numero que estava no visor
    public var temp1: Double = 0
    override func loadView() {
        let view = UIView()
        view.backgroundColor = .black
        //Cria e define os botoes
        for i in 0 ... ButtonNames.count - 1 {
            someButtons.append(UIButton(type: .system))
            someButtons[i].setTitle(ButtonNames[i], for: .normal)
            someButtons[i].titleLabel?.font = UIFont.boldSystemFont(ofSize: 50)
            someButtons[i].contentEdgeInsets = UIEdgeInsetsMake(10,15,10,15)
            someButtons[i].clipsToBounds = true
            someButtons[i].layer.cornerRadius = 40
            someButtons[i].tintColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            someButtons[i].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
            someButtons[i].addTarget(self, action: #selector(ButtonPressed), for: .touchUpInside)
            someButtons[i].tag = i
            view.addSubview(someButtons[i])
    }
        //Cria e define o Label
        label = UILabel()
        label.text = labelText
        label.textColor = #colorLiteral(red: 1.0, green: 1.0, blue: 1.0, alpha: 1.0)
        label.font = label.font.withSize(50)
        view.addSubview(label)
        label.translatesAutoresizingMaskIntoConstraints = false
        //Constraints dos bottoes
        for i in 0 ... ButtonNames.count - 1 {
            someButtons[i].translatesAutoresizingMaskIntoConstraints = false
        }
        //cria o array com todos os constraints de interface
        var NSlayoutArray = [NSLayoutConstraint]()
        //coloca no array os constraints do visor tanto no eixo x como y
            //eixo y
        NSlayoutArray.append(label.topAnchor.constraint(equalTo:view.topAnchor, constant: 5))
            //eixo x
        NSlayoutArray.append(label.rightAnchor.constraint(equalTo:view.rightAnchor, constant: -10))
        for i in 0 ... ButtonNames.count - 1 {
            
            
            if i <= 3 {
                //primeira fileira.
                var Temp:CGFloat = CGFloat((102*i) + 20)
                NSlayoutArray.append(someButtons[i].topAnchor.constraint(equalTo: label.bottomAnchor, constant: 20))
                NSlayoutArray.append(someButtons[i].leftAnchor.constraint(equalTo: view.leftAnchor, constant: Temp))
            } else if i > 3 && i <= 7 {
                //segunda fileira
                var Temp:CGFloat = CGFloat(102*(i-4) + 20)
                NSlayoutArray.append(someButtons[i].topAnchor.constraint(equalTo: someButtons[3].bottomAnchor, constant: 20))
                NSlayoutArray.append(someButtons[i].leftAnchor.constraint(equalTo: view.leftAnchor, constant: Temp))
            } else if i > 7 && i <= 11 {
                //terceira fileira
                var Temp:CGFloat = CGFloat(102*(i-8) + 20)
                NSlayoutArray.append(someButtons[i].topAnchor.constraint(equalTo: someButtons[6].bottomAnchor, constant: 20))
                NSlayoutArray.append(someButtons[i].leftAnchor.constraint(equalTo: view.leftAnchor, constant: Temp))
            }  else if i > 11 && i <= 15 {
                //quarta fileira
                var Temp:CGFloat = CGFloat(102*(i-12) + 20)
                NSlayoutArray.append(someButtons[i].topAnchor.constraint(equalTo: someButtons[8].bottomAnchor, constant: 20))
                NSlayoutArray.append(someButtons[i].leftAnchor.constraint(equalTo: view.leftAnchor, constant: Temp))
            }
        }
        //Config Bottao "0"
        NSlayoutArray.append(someButtons[16].topAnchor.constraint(equalTo: someButtons[14].bottomAnchor, constant: 20))
        NSlayoutArray.append(someButtons[16].leftAnchor.constraint(equalTo: view.leftAnchor, constant: 20))
        //config botao ","
        NSlayoutArray.append(someButtons[17].topAnchor.constraint(equalTo: someButtons[14].bottomAnchor, constant: 20))
        NSlayoutArray.append(someButtons[17].leftAnchor.constraint(equalTo: someButtons[16].rightAnchor, constant: 20))
        //config botao "Hex"
        NSlayoutArray.append(someButtons[18].topAnchor.constraint(equalTo: someButtons[14].bottomAnchor, constant: 20))
        NSlayoutArray.append(someButtons[18].leftAnchor.constraint(equalTo:someButtons[17].rightAnchor, constant:20))
        NSLayoutConstraint.activate(NSlayoutArray)
        
        self.view = view
        
    }
    func Numbers(NumeroPress: Int) {
        //ve se os numeros precionados chegaram no limite do display.
        if labelText.count > 12 {
            //se sim avisar o usuario.
            let alertController = UIAlertController(title: "Você atingiu o meu limite 😓", message:"Eu aguento no maximo 11 digitos", preferredStyle: UIAlertControllerStyle.alert)
            alertController.addAction(UIAlertAction(title: "Me desculpe 😅", style: UIAlertActionStyle.default,handler: nil))
            
            self.present(alertController, animated: true, completion: nil)
            
        } else { 
            //se nao atualizar o display
            //ve se o label esta em 0 ou 0.0
        if labelText == "0" || labelText == "0.0" || labelText.contains("Hex: ") {
            //subistitui o conteudo do visor pelo botao precionado.
            label.text = String(NumeroPress)
            labelText = String(NumeroPress)
            someButtons[18].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
        }
            //se o usuario acabou de fazer uma op. qualquer resultado limpar o diplay 
        else if Operacao == "" && labelText.contains("."){
            labelText = ""
            labelText = labelText + String(NumeroPress)
            label.text = labelText
            Operacao = "0"
            someButtons[18].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
            
        } else {
            //adciona o o botao precionado ao visor
            labelText = labelText + String(NumeroPress)
            label.text = labelText
        }
        }
    }
    //funcao para atualizar a label
    func OperaLabel(Result: Double) {
        labelText = String(Result)
        label.text = labelText
    }
    //funcao para transformar binario para Hexadeciaml
    func binToHex(action: UIAlertAction) {
        // binary to integer:
        let num = labelText.withCString { strtoul($0, nil, 2) }
        // integer to hex:
        let hex = String(num, radix: 16, uppercase: true) // (ou false)
        labelText = hex
        labelText = "Hex: " + labelText
        label.text = labelText
        Operacao = ""
    }
    //funcao para transformar Decimal para Hexadecimal.
    func DecToHex(action: UIAlertAction) {
        var TempDec = Int(labelText)!
        var st = String(format:"%2X", TempDec)
        labelText = st
        labelText = "Hex: " + labelText
        label.text = labelText
        Operacao = ""
    }
    
    func OpPress(ButtonPress: Int, OperationExp: String) {
        if labelText.contains("Hex:") {
            let Alert = UIAlertController(title: "O número ja esta em Hexadecimal", message: "Essa calculadora so converte um numero para hexadecimal. Não mudando o seu modo de uso", preferredStyle: UIAlertControllerStyle.alert)
            Alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
            self.present(Alert, animated: true, completion: nil)
            OperaLabel(Result: 0)
            someButtons[18].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
            
        } else {
        //salva o visor em uma variavel
        temp1 = Double(labelText)!
        //limpa o visor
        OperaLabel(Result: 0)
        //define a flag como subtracao
        Operacao = OperationExp
        //coloca a cor do botao como laranja
        someButtons[ButtonPress].backgroundColor = .orange
        }
    }
    //MARK. Funcao dos botoes pressionados
    @objc func ButtonPressed(sender:UIButton) {
        switch sender.tag {
        case 0:
            //clear
            labelText = "0"
            label.text = labelText
            //volta todos os botoes para a cor original.
            for i in 1 ... ButtonNames.count - 1 {
                someButtons[i].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
            }
            Operacao = "0"
        case 1:
            //soma
            OpPress(ButtonPress: 1, OperationExp: "+")
        case 2:
            //subtraçao
            OpPress(ButtonPress: 2, OperationExp: "-")
        case 3:
            //divisao
            OpPress(ButtonPress: 3, OperationExp: "/")
        case 4:
            //7
            Numbers(NumeroPress: 7)
        case 5:
            //8
            Numbers(NumeroPress: 8)
        case 6:
            //9
            Numbers(NumeroPress: 9)
        case 7:
            //multiplicaçao
            OpPress(ButtonPress: 7, OperationExp: "*")
        case 8:
            //4
            Numbers(NumeroPress: 4)
        case 9:
            //5
            Numbers(NumeroPress: 5)
        case 10:
            //6
            Numbers(NumeroPress: 6)
        case 11:
            //porcentagem
            //pega o numero digitado e divide por 100.
            guard var tempPor: Double = try! Double(labelText) else {
                print("hex")
                break
            }
            tempPor = tempPor / 100.0
            OperaLabel(Result: tempPor)
            
        case 12:
            //1
            Numbers(NumeroPress: 1)
            
        case 13:
            //2
            Numbers(NumeroPress: 2)
            
        case 14:
            //3
            Numbers(NumeroPress: 3)
            
        case 15:
            //MARK. Botao de igual.
            switch Operacao {
            case  "+":
                //se o botao apertado foi de soma. fazer essa op.
                var Temp2 = Double(labelText)
                var temp3 = Temp2! + temp1
                
                OperaLabel(Result: temp3)
                Operacao = ""
            case "-":
                //se o botao apertado foi de subtracao. fazer essa op.
                var Temp2 = Double(labelText)
                var temp3 = temp1 - Temp2!
                OperaLabel(Result: temp3)
                Operacao = ""
            case "/": 
                //se o botao apertado foi de divisao. fazer essa op.
                var Temp2 = Double(labelText)
                var temp3 = temp1 / Temp2!
                OperaLabel(Result: temp3)
                Operacao = ""
            case "*":
                //se o botao apertado foi de multiplicao. fazer essa op.
                var Temp2 = Double(labelText)
                var temp3 = Temp2! * temp1
                OperaLabel(Result: temp3)
                Operacao = ""
                
            default:
                break
            }
            //volta todos os botoes para a cor original.
            for i in 1 ... ButtonNames.count - 1 {
                someButtons[i].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
            }
        case 16:
            //0
            Numbers(NumeroPress: 0)
            
        case 17:
            //virgula
            //checa se o numero ja contem um ponto e se não coloca um.
            if labelText.characters.contains(".") {} else { 
            labelText = labelText + "."
            label.text = labelText
        } 
            case 18:
                //MARK. Outras bases para Hexadecimal.
                if labelText.contains("Hex:") {
                    let Alert = UIAlertController(title: "O número ja esta em Hexadecimal", message: "Essa calculadora so converte um numero para hexadecimal. Não mudando o seu modo de uso", preferredStyle: UIAlertControllerStyle.alert)
                    Alert.addAction(UIAlertAction(title: "Ok", style: UIAlertActionStyle.default, handler: nil))
                    self.present(Alert, animated: true, completion: nil)
                    OperaLabel(Result: 0)
                    someButtons[18].backgroundColor = #colorLiteral(red: 0.803921580314636, green: 0.803921580314636, blue: 0.803921580314636, alpha: 1.0)
                    
                } else {
                    
                    // Checa se o numero digitado é decimal.
                    if labelText.contains("2") || labelText.contains("3") || labelText.contains("4") || labelText.contains("5") || labelText.contains("6") || labelText.contains("7") || labelText.contains("8") || labelText.contains("9")  {
                        //ve se o visor tem um numero double.
                        if labelText.contains("."){
                            //tira o ponto do numero e tudo depois dele
                            labelText.remove(at: labelText.index(before: labelText.endIndex))
                            labelText.remove(at: labelText.index(before: labelText.endIndex))
                        }
                        //faz a conversão de decimal para hexadecimal
                        guard var TempDec: Int = try! Int(labelText) else {
                            break
                        }
                        var st = String(format:"%2X", TempDec)
                        labelText = st
                        Operacao = ""
                        labelText = "Hex: " + labelText
                        label.text = labelText
                    } else {
                        //se o numero não contem nenhum caractere diferente de 0 e 1, mostra um alerta para o usuario perguntando se ele quer converter para hexadecimal baseado de binario ou decimal.
                        let alertController = UIAlertController(title: "Estamos confusos 🤔", message:"O número que você digitou é de tipo:", preferredStyle: UIAlertControllerStyle.alert)
                        //se for binario chama a func binToHex.
                        alertController.addAction(UIAlertAction(title: "Binario", style: UIAlertActionStyle.default,handler: binToHex))
                        //se for decimal chama a func DecToHex.
                        alertController.addAction(UIAlertAction(title: "Números Normais", style: UIAlertActionStyle.default, handler: DecToHex))
                        //mostra o alerta para o usuario
                        self.present(alertController, animated: true, completion: nil)
                        Operacao = ""
                    }
                    someButtons[18].backgroundColor = #colorLiteral(red: 0.937254905700684, green: 0.34901961684227, blue: 0.192156866192818, alpha: 1.0)
                }
                
        default:
            print("error")
        }
        
    }

}

PlaygroundPage.current.liveView = ViewController()
